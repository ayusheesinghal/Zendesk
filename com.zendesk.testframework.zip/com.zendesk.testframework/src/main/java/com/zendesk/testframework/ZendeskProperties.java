package com.zendesk.testframework;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;

public class ZendeskProperties {

	 String user = "ayushee.singhal29@gmail.com/token";
	 String token = "JAGriqYiln351fdRKC5ZUAleCqijs8QxY5sg1FOX";
	 
	 //utility for parsing json object
	 @SuppressWarnings("unchecked")
	JSONObject utility(NewTicket ticket, String req) throws ParseException
	 {
			Gson gson = new Gson();
			String json = gson.toJson(ticket); 
			//JSONObject commentObj = new JSONObject();
			JSONObject obj = new JSONObject();
			JSONParser jsonparse = new JSONParser();
			obj.put(req, (JSONObject)jsonparse.parse(json));
			return obj;
	 }
}
