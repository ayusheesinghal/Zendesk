package com.zendesk.testframework;

public class NewTicket {
	String subject;
	Comment comment;
	
	public NewTicket(String subject, Comment comment) {
		super();
		this.subject = subject;
		this.comment = comment;
	}
	public NewTicket(Comment comment) {
		super();
		this.comment = comment;
	}
}
