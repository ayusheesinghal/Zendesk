package com.zendesk.testframework;

public class Comment {

	String body;
	int author_id;
	
 public Comment(String body, int author_id) {
	 this.body = body;
	 this.author_id = author_id;
		// TODO Auto-generated constructor stub
	}
}
