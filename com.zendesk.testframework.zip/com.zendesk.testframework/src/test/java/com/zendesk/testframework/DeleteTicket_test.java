package com.zendesk.testframework;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;


import org.json.simple.parser.ParseException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class DeleteTicket_test {

	ZendeskProperties property = new ZendeskProperties();
	int id=0;
	@BeforeTest
	public void initial() throws ParseException
	{
	baseURI = "https://ayusheesinghal.zendesk.com";
	
	}
	//getting ticket details and retrieving 1st id to delete
	@Test(priority = 1)
	public void getTicket()
	{
		Response response = given().auth().basic(property.user, property.token).param("sort_by", "id")
		.get("/api/v2/tickets.json");
		response.then().assertThat().statusCode(200)
		.and()
		.contentType(ContentType.JSON);
		
		id = response.getBody().jsonPath().get("tickets.id[0]");
		System.out.println("Deleting ticket:" + id);
		
	}
	
	//deleting first record retrieved
	@Test(priority = 2)
	public void deleteTicket()
	{
		//deleting ticket
		Response response = given().pathParam("id", id)
				.auth().basic(property.user, property.token)
				.delete("/api/v2/tickets/{id}.json");
		
		response.then().assertThat().statusCode(204);
		
	}
	
	//verifying deleted ticket is not present any more
	@Test(priority = 3)
	public void verifyDeletedTicket()
	{
		given().pathParam("id", id)
		.auth().basic(property.user, property.token)
				.get("/api/v2/tickets/{id}.json").then()
				.assertThat()
					.statusCode(404)
					.body("error", equalTo("RecordNotFound"));
		
		System.out.println("verified deleted ticket " + id);
	}
}
