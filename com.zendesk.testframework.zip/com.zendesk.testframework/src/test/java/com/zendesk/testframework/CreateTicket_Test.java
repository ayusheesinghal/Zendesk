package com.zendesk.testframework;


import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;


import org.testng.annotations.*;
import io.restassured.http.ContentType;

import io.restassured.response.Response;
import org.json.simple.parser.ParseException;


public class CreateTicket_Test {

	ZendeskProperties property = new ZendeskProperties();
	String subject = "My monitor is not working";
	String comment = "The lights are green.";
	NewTicket newtick = new NewTicket(subject, new Comment(comment,123));
	
	int id=0;
	
	@BeforeTest
	public void initial() throws ParseException
	{
		baseURI = "https://ayusheesinghal.zendesk.com";
	}
	
	
	@Test(priority = 1)
	public void createTicket() throws ParseException
	{
		Response response = given().auth()
						.basic(property.user, property.token)
						.contentType("application/json")
						.body(property.utility(newtick, "ticket").toString())
					.post("/api/v2/tickets.json");
		
		response.then().assertThat()
			.statusCode(201)
		.and()
			.body("ticket.subject", equalTo(subject));
		
		System.out.println("Ticket Created Successfully ");
	}
	
	@Test(priority = 2)
	public void getTicket()
	{
		Response response = given().auth()
				.basic(property.user, property.token)
					.param("sort_by", "id")
				.get("/api/v2/tickets.json");
		
		response.then().assertThat()
			.statusCode(200)
		.and()
			.contentType(ContentType.JSON);
		id = response.getBody().jsonPath().get("tickets.id[0]");
		System.out.println("Able to retrieve new created ticket");
	}

	
}
