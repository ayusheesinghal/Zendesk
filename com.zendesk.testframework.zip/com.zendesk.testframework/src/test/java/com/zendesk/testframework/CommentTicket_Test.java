
package com.zendesk.testframework;


import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.json.simple.parser.ParseException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CommentTicket_Test {

	String newComment = "Issue has been resolved.";
	ZendeskProperties property = new ZendeskProperties();
	NewTicket updateTicket = new NewTicket(new Comment(newComment,123));

	int id=0;
	//@SuppressWarnings("unchecked")
	@BeforeTest
	public void initial() throws ParseException
	{
		
	baseURI = "https://ayusheesinghal.zendesk.com";
	
	}
	@Test(priority = 1)
	public void getTicket()
	{
		Response response = given().auth().basic(property.user, property.token)
		.get("/api/v2/tickets.json");
		response.then().assertThat().statusCode(200)
		.and()
		.contentType(ContentType.JSON);
		
		id = response.getBody().jsonPath().get("tickets.id[0]");
	}
	
	//verifying new comment is created
	@Test(priority = 2)
	public void createComment() throws ParseException
	{
		Response response = given().pathParam("id", id)
				.auth()
					.basic(property.user, property.token)
					.pathParam("id", id)
					.contentType("application/json")
					.body(property.utility(updateTicket, "request").toString())
				.put("/api/v2/requests/{id}.json");
		response.then().assertThat().statusCode(200)
		.and()
		.body("request.id", equalTo(id));
		System.out.println("comment created successfully");
	}
	
	//verifying new comment is returned in list of comments
	@Test(priority = 3)
	public void verifyAddedComment()
	{
		Response response = given().pathParam("id", id)
				.auth()
					.basic(property.user, property.token)
					.contentType("application/json")
				.get("/api/v2/requests/{id}/comments.json");
		
		response.then().assertThat().statusCode(200);
		response.then().assertThat().body("comments.body" , hasItems(newComment));
		System.out.println("comment verified successfully");
	}
	
	
}
