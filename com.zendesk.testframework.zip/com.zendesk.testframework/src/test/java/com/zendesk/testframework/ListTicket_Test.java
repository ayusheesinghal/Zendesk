package com.zendesk.testframework;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

import java.util.ArrayList;

import org.json.simple.parser.ParseException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ListTicket_Test {

	ZendeskProperties property = new ZendeskProperties();
	int id=0;
	@BeforeTest
	public void initial() throws ParseException
	{
	baseURI = "https://ayusheesinghal.zendesk.com";
	}
	
	@Test(priority = 1)
	public void getTicket()
	{
		Response response = given().auth().basic(property.user, property.token).param("sort_by", "id")
		.get("/api/v2/tickets.json");
		response.then().assertThat()
			.statusCode(200)
		.and()
			.contentType(ContentType.JSON);
		response.then().assertThat().body("tickets", notNullValue());

		JsonPath json = response.jsonPath();
		ArrayList<Integer> ticketIDs = json.get("tickets.id");
		System.out.println("returned tickets");
		for(Integer temp: ticketIDs)
		{
			System.out.println(temp);
		}
		
	}
}
